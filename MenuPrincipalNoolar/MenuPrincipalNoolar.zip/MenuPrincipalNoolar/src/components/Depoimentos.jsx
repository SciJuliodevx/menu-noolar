// import React from 'react';
// import '../components/css/Depoimento.css'
// function Depoimento({ description, title, subtitulo }) {
//     return (
//         <>

//         <div className="card-container2">
//             <h2>depoimentos</h2>
//             <p className="card-text">{description}</p>
//             <h3 className="card-title">{title}</h3>
//             <h2 className='card-subtitulo'>{subtitulo}</h2>
//             <div className="imgBG">
//             </div>
//         </div>
//         </>
//     );
// }

// export default Depoimento;