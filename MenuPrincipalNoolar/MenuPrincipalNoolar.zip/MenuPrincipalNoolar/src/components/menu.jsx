import "./css/MainMenuStyle.css";

function MainMenu(){
  return (
    // Tela Inicial
    <div className="container">
      <div className="title">
        <h1>Noolar</h1>
        <p>
          Um lar acolhedor para
          <span className="OrangeText"> Imigrantes </span>
          do
          <span className="OrangeText"> Mercosul </span> e
          <span className="OrangeText"> América Latina. </span>
        </p>
      </div>
      <div className="globoDiv">
        <img
          className="globoImg"
          src="../../public/images/GloboMenu.png"
          alt=""
        />
      </div>
      <div className="bgImage">
        <img src="../../public/images/BgMenu.png" alt="" />
      </div>
        <div className="transition1">
            <div className="desc1">
              <p>
              Noolar é uma plataforma inteligente para <span className="OrangeText">Imigrantes Latinos!</span>
              </p>
            </div>
            <div className="circulo">
              <img src='\public\images\circulo.png'
               alt="imagem de um circulo" />
            </div>
            <div className="imigrante1">
              <img src= "../public/images/imig1.png"
               alt="" />
            </div>
        </div>

        
    </div>
      
  );
}
export default MainMenu;
