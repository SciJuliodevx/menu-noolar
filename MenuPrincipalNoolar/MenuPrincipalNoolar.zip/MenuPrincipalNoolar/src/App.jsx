import "./App.css";
import MainMenu from "./components/menu";

function App() {
  return (
    <>
      {/* <Navbar /> */}
      <MainMenu />
      {/* <Footer /> */}
    </>
  );
}

export default App;
